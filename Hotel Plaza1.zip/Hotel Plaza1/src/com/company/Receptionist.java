package com.company;

public class Receptionist extends Staff{
    public Receptionist(String title, String name, int telephoneNumber) {
        super(title, name, telephoneNumber);
    }
}
