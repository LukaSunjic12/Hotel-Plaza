package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    public void staffMenu() {

        Scanner scanner = new Scanner(System.in);
        while (1 == 1) {
            System.out.println("Press 1 to create a room");
            System.out.println("Press 2 for booking");
            System.out.println("Press 3 to exit");

            int options = scanner.nextInt();
            boolean exit = false;
            switch (options) {
                case 1: //create a room
                    System.out.println("Enter room number:");
                    int roomNum = scanner.nextInt();
                    System.out.println("Enter number of beds:");
                    int bedsNum = scanner.nextInt();
                    System.out.println("Does the room have internet access [true/false]:");
                    boolean internet = scanner.nextBoolean();
                    System.out.println("Enter room price:");
                    double price = scanner.nextDouble();
                    System.out.println("Enter room type:");
                    String roomType = scanner.next();
                    Room newRoom = new Room(roomNum, bedsNum, internet, price, roomType);

                    break;
                case 2:
                    break;
                case 3:
                    exit = true;
                    break;
                /*case 4:
                    System.out.println("Enter end date");
                    break;
                case 5:
                    System.out.println("Confirm your booking");*/
            }
            if (exit) {
                System.out.println("Goodbye!");
                break;
            }
        }
    }
}
