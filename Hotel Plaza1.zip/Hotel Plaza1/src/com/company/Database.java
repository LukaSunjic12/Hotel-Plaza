package com.company;

public class Database {
    import java.io.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


    public class database<initialCreation> {
        initialCreation();
        return initialCreation;
        public static <T> Set<T> mergeSet(Set<T> a, Set<T> b) {
        }

        public static void main(String[] args) {
            try {
                Set<char> rooms.add<char>():

                a.addAll(char.asList(new char[][] { Room room1, Room room2, Room room11, Room room12, Room room21, Room22  }));
            } catch (Exception e) {
                e.printStackTrace();
            }
            Set<String>guests.add<char>();
            a.addAll(char.asList(new guest[][] {guest1, guest2, guest3, guest4, guest5, guest6, guest7, guest8}))
        }
        public static void save(Hotel database) {
            try {
                FileOutputStream fileOut = new FileOutputStream("database");
                ObjectOutputStream out = new ObjectOutputStream(fileOut);
                out.writeObject(database);
                out.close();
                fileOut.close();
                System.out.printf("This data is saved in database");
            } catch (IOException i) {
                i.printStackTrace();
            }
        }

        initialCreation();
    }

}
}
