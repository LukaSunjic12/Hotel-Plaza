package com.company;

public class Director extends Staff{

    public Director(String title, String name, int telephoneNumber) {
        super(title, name, telephoneNumber);
    }
}
