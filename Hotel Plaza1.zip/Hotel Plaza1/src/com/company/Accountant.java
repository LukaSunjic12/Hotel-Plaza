package com.company;

public class Accountant extends Staff{
    public Accountant(String title, String name, int telephoneNumber) {
        super(title, name, telephoneNumber);
    }
}
