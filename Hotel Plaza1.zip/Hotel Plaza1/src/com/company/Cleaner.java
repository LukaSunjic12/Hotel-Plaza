package com.company;

public class Cleaner extends Staff{
    public Cleaner(String title, String name, int telephoneNumber) {
        super(title, name, telephoneNumber);
    }
}
