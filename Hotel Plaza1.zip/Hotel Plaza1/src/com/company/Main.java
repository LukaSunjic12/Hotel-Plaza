package com.company;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;


public class Main {
    public long nextLong(){
        return nextLong();
    }

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.staffMenu();


    }
}


