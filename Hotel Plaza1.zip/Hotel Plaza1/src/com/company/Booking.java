package com.company;

public class Booking {
    private Staff


    private int booking_id;
    private long checkInDate;
    private long checkOutDate;
    private Guest guest;
    private int noOfNights;
}
