package com.company;

import java.io.FileWriter;
import java.util.ArrayList;

public class Booking {
    private int booking_id;
    private long checkInDate;
    private long checkOutDate;
    private Guest guest;
    private int numberOfNights;
    private Room room;

    public Booking(int booking_id, long checkInDate, long checkOutDate, String room, String guest, int numberOfNights) {
        ArrayList<Room>rooms=new ArrayList<>();
    }
    public int getBooking_id() {
        return booking_id;
    }
    public long getCheckInDate() {
        return checkInDate;
    }
    public long getCheckOutDate() {
        return checkOutDate;
    }
    public int getNumberOfNights() {
        return numberOfNights;
    }
    public Guest getGuest() {
        return guest;
    }
    public  Room getRoom(){return room;}

    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

    public void setCheckInDate(long checkInDate) {
        this.checkInDate = checkInDate;
    }

    public void setCheckOutDate(long checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    public void setNumberOfNights(int numberOfNights) {
        this.numberOfNights = numberOfNights;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

}


